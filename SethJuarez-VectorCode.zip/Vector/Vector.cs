﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Vector
{
    public class Vector : IEnumerable<double>
    {
        private double[] _vector;
        public Vector() { }
        public Vector(int length) { _vector = new double[length]; }
        public Vector(double[] vector) { _vector = vector; }
        public int Length { get { return _vector.Length; } }

        public double this[int i]
        {
            get { return _vector[i]; }
            set { _vector[i] = value; }
        }

        public double this[Func<double, bool> criteria]
        {
            set
            {
                for (int i = 0; i < Length; i++)
                    if (criteria(this[i]))
                        this[i] = value;
            }
        }

        public static implicit operator Vector(double[] array)
        {
            return new Vector(array.ToArray());
        }

        public static implicit operator Vector(int[] array)
        {
            return new Vector(array.Select(i => (double)i).ToArray());
        }

        public static explicit operator Vector(double i)
        {
            return new Vector(new[] { i });
        }

        public static Vector Operation(Vector one, Vector two,
            Func<double, double, double> op)
        {
            if (one.Length == two.Length)
            {
                Vector three = new Vector(one.Length);
                for (int i = 0; i < one.Length; i++)
                    three[i] = op(one[i], two[i]);
                return three;
            }
            else throw new InvalidOperationException("Improper vector lengths");
        }

        public static Vector operator +(Vector one, Vector two)
        {
            return Operation(one, two, (o, t) => o + t);
        }

        public static Vector operator -(Vector one, Vector two)
        {
            return Operation(one, two, (o, t) => o - t);
        }

        public static Vector operator *(Vector one, Vector two)
        {
            return Operation(one, two, (o, t) => o * t);
        }

        public static Vector operator /(Vector one, Vector two)
        {
            return Operation(one, two, (o, t) => o / t);
        }

        public IEnumerator<double> GetEnumerator()
        {
            for (int i = 0; i < Length; i++)
                yield return this[i];
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            for (int i = 0; i < Length; i++)
                yield return this[i];
        }
    }
}
