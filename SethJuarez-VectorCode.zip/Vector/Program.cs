﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Vector
{
    delegate int Foo(int i);

    class Program
    {
        static void Main(string[] args)
        {
            Foo f = i => i * i;

            Vector v = new[] { 1, 2, 3, 4, 5, 6, 7 };
            double first = v[0];

            Vector one = new[] { 1, 0, 0, 4, 5, 0, 7 };
            one[d => d == 0] = -1;

            Vector two = new[] { 1, 2, 3, 4, 5, 6, 7 };

            Vector three = one + two;

            foreach (double item in three)
            {
                Console.WriteLine(item);
                if (item > 10) break;
            }

            Vector observations = new[] { 1, 0, 0, 4, 5, 0, 7 };
            Vector output = observations
                            .Filter(d => d > 0)
                            .Do(d => Math.Sqrt(d))
                            .Filter(d => d > 1)
                            .Do(d => Math.Pow(d, 3.4))
                            .ToArray();
        }
    }
}
