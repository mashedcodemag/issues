﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Vector
{
    public static class VectorHelpers
    {
        public static IEnumerable<double> Filter(
            this IEnumerable<double> vector,
            Func<double, bool> op)
        {
            foreach (double item in vector)
                if (op(item))
                    yield return item;
        }

        public static IEnumerable<double> Do(
            this IEnumerable<double> vector,
            Func<double, double> op)
        {
            foreach (double item in vector)
                yield return op(item);
        }
    }
}
